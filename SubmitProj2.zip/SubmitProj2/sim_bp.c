#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sim_bp.h"

/*  argc holds the number of command line arguments
    argv[] holds the commands themselves

    Example:-
    sim bimodal 6 gcc_trace.txt
    argc = 4
    argv[0] = "sim"
    argv[1] = "bimodal"
    argv[2] = "6"
    ... and so on
*/
int main (int argc, char* argv[])
{
    FILE *FP;               // File handler
    char *trace_file;       // Variable that holds trace file name;
    bp_params params;       // look at sim_bp.h header file for the the definition of struct bp_params
    char outcome;           // Variable holds branch outcome
    unsigned long int addr; // Variable holds the address read from input file
    int predictor_type = -1;
    enum predictor_types { BIMODAL = 0, GSHARE, HYBRID };
    
    if (!(argc == 4 || argc == 5 || argc == 7))
    {
        printf("Error: Wrong number of inputs:%d\n", argc-1);
        exit(EXIT_FAILURE);
    }
    
    params.bp_name  = argv[1];
    
    // strtoul() converts char* to unsigned long. It is included in <stdlib.h>
    if(strcmp(params.bp_name, "bimodal") == 0)              // Bimodal
    {
        if(argc != 4)
        {
            printf("Error: %s wrong number of inputs:%d\n", params.bp_name, argc-1);
            exit(EXIT_FAILURE);
        }
        params.M2       = strtoul(argv[2], NULL, 10);
        trace_file      = argv[3];
        printf("COMMAND\n%s %s %lu %s\n", argv[0], params.bp_name, params.M2, trace_file);
        predictor_type = BIMODAL;
    }
    else if(strcmp(params.bp_name, "gshare") == 0)          // Gshare
    {
        if(argc != 5)
        {
            printf("Error: %s wrong number of inputs:%d\n", params.bp_name, argc-1);
            exit(EXIT_FAILURE);
        }
        params.M1       = strtoul(argv[2], NULL, 10);
        params.N        = strtoul(argv[3], NULL, 10);
        trace_file      = argv[4];
        printf("COMMAND\n%s %s %lu %lu %s\n", argv[0], params.bp_name, params.M1, params.N, trace_file);
        predictor_type = GSHARE;
    }
    else if(strcmp(params.bp_name, "hybrid") == 0)          // Hybrid
    {
        if(argc != 7)
        {
            printf("Error: %s wrong number of inputs:%d\n", params.bp_name, argc-1);
            exit(EXIT_FAILURE);
        }
        params.K        = strtoul(argv[2], NULL, 10);
        params.M1       = strtoul(argv[3], NULL, 10);
        params.N        = strtoul(argv[4], NULL, 10);
        params.M2       = strtoul(argv[5], NULL, 10);
        trace_file      = argv[6];
        printf("COMMAND\n%s %s %lu %lu %lu %lu %s\n", argv[0], params.bp_name, params.K, params.M1, params.N, params.M2, trace_file);

        predictor_type = HYBRID;
    }
    else
    {
        printf("Error: Wrong branch predictor name:%s\n", params.bp_name);
        exit(EXIT_FAILURE);
    }
    
    // Open trace_file in read mode
    FP = fopen(trace_file, "r");
    if(FP == NULL)
    {
        // Throw error and exit if fopen() failed
        printf("Error: Unable to open file %s\n", trace_file);
        exit(EXIT_FAILURE);
    }

    if(predictor_type == HYBRID)
    {
        printf("Error: hybrid predictor is not implemented for ECE 463 requirements.\n");
        fclose(FP);
        exit(EXIT_FAILURE);
    }

    unsigned char *predictor_table = NULL;
    size_t table_size = 0;
    unsigned long int index_mask = 0;
    unsigned long int history_mask = 0;
    unsigned long int history = 0;
    unsigned long int branch_index = 0;
    unsigned long long predictions = 0;
    unsigned long long mispredictions = 0;
    unsigned long int history_shift = 0;
    unsigned long int lower_mask = 0;

    if(predictor_type == BIMODAL)
    {
        if(params.M2 > (sizeof(unsigned long int) * 8))
        {
            printf("Error: M2 is too large:%lu\n", params.M2);
            fclose(FP);
            exit(EXIT_FAILURE);
        }
        table_size = 1ULL << params.M2;
        predictor_table = (unsigned char*)malloc(table_size * sizeof(unsigned char));
        if(predictor_table == NULL)
        {
            printf("Error: Unable to allocate memory for bimodal predictor table\n");
            fclose(FP);
            exit(EXIT_FAILURE);
        }
        for(size_t i = 0; i < table_size; ++i)
        {
            predictor_table[i] = 2; // Initialize to weakly taken
        }
        index_mask = (table_size > 0) ? (unsigned long int)(table_size - 1) : 0;
    }
    else if(predictor_type == GSHARE)
    {
        if(params.N > params.M1)
        {
            printf("Error: N cannot be greater than M1 for gshare predictor\n");
            fclose(FP);
            exit(EXIT_FAILURE);
        }
        if(params.M1 > (sizeof(unsigned long int) * 8))
        {
            printf("Error: M1 is too large:%lu\n", params.M1);
            fclose(FP);
            exit(EXIT_FAILURE);
        }
        table_size = 1ULL << params.M1;
        predictor_table = (unsigned char*)malloc(table_size * sizeof(unsigned char));
        if(predictor_table == NULL)
        {
            printf("Error: Unable to allocate memory for gshare predictor table\n");
            fclose(FP);
            exit(EXIT_FAILURE);
        }
        for(size_t i = 0; i < table_size; ++i)
        {
            predictor_table[i] = 2; // Initialize to weakly taken
        }
        index_mask = (table_size > 0) ? (unsigned long int)(table_size - 1) : 0;
        if(params.N > 0)
        {
            history_mask = (1ULL << params.N) - 1;
            history_shift = params.M1 - params.N;
            lower_mask = (params.M1 > params.N) ? ((1ULL << (params.M1 - params.N)) - 1) : 0;
        }
    }

    if(predictor_table == NULL)
    {
        printf("Error: Predictor table not initialized\n");
        fclose(FP);
        exit(EXIT_FAILURE);
    }
    
    char str[2];
    while(fscanf(FP, "%lx %s", &addr, str) != EOF)
    {
        outcome = str[0];
        int actual_taken = (outcome == 't') ? 1 : 0;
        unsigned char counter_value = 2;

        unsigned long int pc_shifted = addr >> 2;

        if(predictor_type == BIMODAL)
        {
            branch_index = pc_shifted & index_mask;
        }
        else if(predictor_type == GSHARE)
        {
            unsigned long int pc_index = pc_shifted & index_mask;
            if(params.N == 0)
            {
                branch_index = pc_index;
            }
            else
            {
                unsigned long int upper_bits = pc_index >> history_shift;
                unsigned long int xor_value = (upper_bits ^ history) & history_mask;
                unsigned long int lower_bits = (params.M1 > params.N) ? (pc_index & lower_mask) : 0;
                branch_index = (xor_value << history_shift) | lower_bits;
            }
        }

        counter_value = predictor_table[branch_index];
        int predicted_taken = (counter_value >= 2) ? 1 : 0;

        predictions++;
        if(predicted_taken != actual_taken)
        {
            mispredictions++;
        }

        if(actual_taken)
        {
            if(counter_value < 3)
            {
                counter_value++;
            }
        }
        else
        {
            if(counter_value > 0)
            {
                counter_value--;
            }
        }

        predictor_table[branch_index] = counter_value;

        if(predictor_type == GSHARE && params.N > 0)
        {
            history = history >> 1;
            if(actual_taken)
            {
                history |= (1ULL << (params.N - 1));
            }
            history &= history_mask;
        }
    }

    fclose(FP);

    printf("OUTPUT\n");
    printf(" number of predictions:    %llu\n", predictions);
    printf(" number of mispredictions: %llu\n", mispredictions);
    if(predictions == 0)
    {
        printf(" misprediction rate:       0.00%%\n");
    }
    else
    {
        double misprediction_rate = ((double)mispredictions / (double)predictions) * 100.0;
        printf(" misprediction rate:       %.2f%%\n", misprediction_rate);
    }

    if(predictor_type == BIMODAL)
    {
        printf("FINAL BIMODAL CONTENTS\n");
    }
    else if(predictor_type == GSHARE)
    {
        printf("FINAL GSHARE CONTENTS\n");
    }

    for(size_t i = 0; i < table_size; ++i)
    {
        printf(" %lu\t%u\n", (unsigned long)i, predictor_table[i]);
    }

    free(predictor_table);

    return 0;
}
